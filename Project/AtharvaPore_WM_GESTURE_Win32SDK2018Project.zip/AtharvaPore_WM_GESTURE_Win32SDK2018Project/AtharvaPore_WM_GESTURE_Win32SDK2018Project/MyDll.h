#pragma once

extern "C" double Mass(double);
extern "C" double Weight(double, double);
extern "C" double PersonWeight(double ms);
