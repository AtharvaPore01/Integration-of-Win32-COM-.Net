#pragma once
extern "C" double FirstSide(double, double, double, double);
extern "C" double SecondSide(double, double, double, double);
extern "C" double ThirdSide(double, double, double, double);
extern "C" double TriangleIs(double, double, double);
extern "C" double AngleIs(double, double, double);
